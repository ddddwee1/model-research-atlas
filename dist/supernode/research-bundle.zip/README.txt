Model Research Atlas: Supernode supplement

This is a supplemental research and budgeting package. It is not an execution guarantee,
hardware benchmark, or independently audited certification. Scenario values are editable
assumptions; inspect report.md and source registers before relying on them. The package
contains 156 model-scope supplements. Only Kimi-K3 has a scenario baseline in this study;
other models are scope/gap records and do not inherit K3 cache geometry.

CSV files use UTF-8 with BOM. Scenario capacity snapshots are a bounded matrix across
three representative platforms and do not claim backend support. The interactive calculator
and full hardware catalog remain available on the hosted site.
